from scrapy import Spider, Request
from sorosfund.items import SorosfundItem
import re
import math


class SorosfundSpider(Spider):
    name = 'sorosfund_spider'
    allowed_urls = ['https://www.sec.gov/edgar/searchedgar/companysearch.html']
    start_urls = ['https://www.sec.gov/Archives/edgar/data/1029160/000156761919011174/xslForm13F_X01/form13fInfoTable.xml']


    def parse(self, response):
        rows = response.xpath('/html/body/table[2]/tbody/tr')

        for row in rows:
                name = row.xpath('./td[1]/text()').extract_first()
                title = row.xpath('./td[2]/text()').extract_first()
                cusip = row.xpath('./td[3]/text()').extract_first()
                value = row.xpath('./td[4]/text()').extract_first()
                shares = row.xpath('./td[5]/text()').extract_first()



                item = SorosfundItem()
                item['company'] = 'SOROS FUND'
                item['name'] = name
                item['title'] = title
                item['cusip'] = cusip
                item['value'] = value
                item['shares'] = shares
                yield item