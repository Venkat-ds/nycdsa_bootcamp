from scrapy import Spider, Request
from brkshire.items import BrkshireItem
import re
import math


class BrkshireSpider(Spider):
    name = 'brkshire_spider'
    allowed_urls = ['https://www.sec.gov/edgar/searchedgar/companysearch.html']
    start_urls = ['https://www.sec.gov/Archives/edgar/data/1067983/000095012319005436/xslForm13F_X01/form13fInfoTable.xml']


    def parse(self, response):
        rows = response.xpath('//html/body/table[2]/tbody/tr')

        for row in rows:
                name = row.xpath('./td[1]/text()').extract_first()
                title = row.xpath('./td[2]/text()').extract_first()
                cusip = row.xpath('./td[3]/text()').extract_first()
                value = row.xpath('./td[4]/text()').extract_first()
                shares = row.xpath('./td[5]/text()').extract_first()



                item = BrkshireItem()
                item['company'] = 'BERKSHIRE HATHAWAY'
                item['name'] = name
                item['title'] = title
                item['cusip'] = cusip
                item['value'] = value
                item['shares'] = shares
                yield item